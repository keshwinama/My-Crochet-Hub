# Stitch & Bloom 5.0

## Run it
1. Extract the ZIP.
2. Open the `stitch_and_bloom_5` folder.
3. Double-click `index.html` (or open it with Chrome/Edge).

No installation or server is required.

## Important notes
- Your entries are saved in your browser using localStorage on this device/browser.
- Use the app in the same browser to see your saved data.
- Clearing browser site data can erase the app's saved entries. Export/backup support can be added in a later version; the current app stores all records locally.
- Pattern links are saved as links and notes. This version does not upload PDF files to cloud storage.
- The app is a working starter version of the 12 requested areas. Some advanced features such as cloud sync, full PDF file management, photo attachments, detailed stitch diagrams, and more advanced garment calculators can be added in later iterations.
